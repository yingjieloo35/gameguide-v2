// Hamburger
const hb = document.getElementById('hamburger');
const dr = document.getElementById('navDrawer');
if (hb && dr) {
  hb.addEventListener('click', () => { hb.classList.toggle('open'); dr.classList.toggle('open'); });
  dr.querySelectorAll('a').forEach(a => a.addEventListener('click', () => { hb.classList.remove('open'); dr.classList.remove('open'); }));
}
// Smooth scroll to hash on load
window.addEventListener('load', () => {
  if (location.hash) { const el = document.querySelector(location.hash); if (el) setTimeout(() => el.scrollIntoView({ behavior: 'smooth', block: 'start' }), 200); }
});
